module.exports = Object.freeze([{
  LocalObservationDateTime: '2022-02-09T13:44:00-05:00',
  WeatherText: 'Mostly cloudy',
  WeatherIcon: 6,
  HasPrecipitation: false,
  PrecipitationType: null,
  MobileLink: 'http://www.accuweather.com/en/us/columbus-oh/43215/current-weather/350128?lang=en-us',
  Link: 'http://www.accuweather.com/en/us/columbus-oh/43215/current-weather/350128?lang=en-us',
  city: 'Columbus',
  state: 'OH',
  locationId: 350128,
  statusCode: 200
}])